# Rocky v1: print settings

STLs exported from the CAD on 14 Nov 2026 (the as-built v1, before any v2 fixes). They are already in print orientation: don't auto-orient.

Printed on a Prusa CORE One+ (0.4 mm nozzle, 0.2 mm layers) in PETG. Defaults: 3 walls, 15 % gyroid, unless the table says otherwise.

| STL | Qty | Material | Settings | Supports |
|---|---|---|---|---|
| carapace.stl (the shell) | 1 | PETG | upside down, plateau on the bed, ~5.5 h | none |
| chassis.stl (base plate) | 1 | PETG | 4 walls, 25 % gyroid, ~3 h | none |
| femur_R_x3 / femur_L_x2 (upper legs) | 3 + 2 | PETG | 4 walls, 40 % gyroid | build plate only |
| femur_cap_R_x3 / femur_cap_L_x2 (leg lids) | 3 + 2 | PETG | flat | none |
| tibia_R_x3 / tibia_L_x2 (lower legs) | 3 + 2 | PETG | 4 walls, 40 % gyroid | none |
| hip_bracket_R_x3 / hip_bracket_L_x2 | 3 + 2 | PETG | 4 walls, 40 % gyroid, bearing ring down | tree support under the pad |
| foot_boot_TPU_x5 | 5 | TPU 95A | 3 walls, 100 %, slow (20-25 mm/s) | none |
| drawer.stl | 1 | PETG | shelf top on the bed | build plate only |
| drawer_strap_ubec / drawer_strap_buck / board_strap_amp / board_strap_bno | 1 each | PETG | flat | none |
| eye_ring, mic_clip_x2, tof_carrier, tof_clamp, camera_carrier, urt2_spacer | as named | PETG | flat | none |
| battery_saddle, carabiner_loop, side_plate_usb, charge_dock | 1 each | PETG | | carabiner: tree supports |

## Lessons baked in

- This printer prints holes and pockets 0.3 to 0.5 mm small and outside faces 0.3 mm fat in PETG. Model at least 0.6 mm per side of clearance around bought parts.
- Print one test piece (a single knee) and take one caliper reading before printing a full set.
- One object per part on the plate, so one failed part can be cancelled without killing the rest.
- Nothing should start in mid-air: check the sliced preview layer by layer for islands and unwanted supports.

## Known v1 issues (fix these in your version)

- The 10 mm battery-lead hole is too small for the barrel plug.
- The mic pockets need a wire notch on the label side.
- On some hips the horn's centre hole doesn't line up with the disc's centre hole.
- The back leg's knee-cable slot overlaps the speaker ring.

License: free for personal, non-commercial use. Built by Alexander Gouyet with Claude. https://alexandergouyet.com/blog/rocky
